-- MySQL dump 10.10
--
-- Host: localhost    Database: fz_cms
-- ------------------------------------------------------
-- Server version	5.0.22-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_attachment`
--

DROP TABLE IF EXISTS `t_attachment`;
CREATE TABLE `t_attachment` (
  `id` int(11) NOT NULL auto_increment,
  `is_attach` int(11) default NULL,
  `is_img` int(11) default NULL,
  `is_index_pic` int(11) default NULL,
  `new_name` varchar(255) default NULL,
  `old_name` varchar(255) default NULL,
  `size` bigint(20) NOT NULL,
  `suffix` varchar(255) default NULL,
  `type` varchar(255) default NULL,
  `tid` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK48549DCE48978EFA` (`tid`),
  CONSTRAINT `FK48549DCE48978EFA` FOREIGN KEY (`tid`) REFERENCES `t_topic` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_attachment`
--


/*!40000 ALTER TABLE `t_attachment` DISABLE KEYS */;
LOCK TABLES `t_attachment` WRITE;
INSERT INTO `t_attachment` VALUES (1,1,1,1,'1442325677036.jpg','16adb4259a1571160d838770dea250da',206320,'jpg','application/octet-stream',1),(2,1,1,1,'1442325677347.jpg','1680_1050_4090',164315,'jpg','application/octet-stream',1),(3,0,1,1,'1442325677577.jpg','112976845199593',284726,'jpg','application/octet-stream',1),(4,1,1,1,'1442325677997.jpg','c_1680_1050_4302',374783,'jpg','application/octet-stream',1),(5,0,1,1,'1442325678277.jpg','u=89686551,84464882&fm=24&gp=0',359005,'jpg','application/octet-stream',1),(6,0,1,1,'1442325678588.jpg','u=161726554,889081684&fm=24&gp=0',282120,'jpg','application/octet-stream',1),(7,0,1,1,'1442325678758.jpg','u=261825178,2216988228&fm=24&gp=0',74186,'jpg','application/octet-stream',1),(8,1,1,1,'1442325679188.jpg','u=269340252,3016703433&fm=24&gp=0',231546,'jpg','application/octet-stream',1),(9,0,1,1,'1442325679448.jpg','u=271671913,1655905436&fm=24&gp=0',106230,'jpg','application/octet-stream',1),(10,1,1,1,'1442325679699.jpg','u=457112284,3017587389&fm=24&gp=0',37552,'jpg','application/octet-stream',1),(11,0,1,1,'1442325679889.jpg','u=503986431,2927337343&fm=24&gp=0',83043,'jpg','application/octet-stream',1);
UNLOCK TABLES;
/*!40000 ALTER TABLE `t_attachment` ENABLE KEYS */;

--
-- Table structure for table `t_channel`
--

DROP TABLE IF EXISTS `t_channel`;
CREATE TABLE `t_channel` (
  `id` int(11) NOT NULL auto_increment,
  `custom_link` int(11) default NULL,
  `custom_link_url` varchar(255) default NULL,
  `is_index` int(11) default NULL,
  `is_top_nav` int(11) default NULL,
  `name` varchar(255) NOT NULL,
  `nav_order` int(11) default NULL,
  `orders` int(11) NOT NULL,
  `recommend` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `type` int(11) default NULL,
  `pId` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FKE79D7038EA50D0CA` (`pId`),
  CONSTRAINT `FKE79D7038EA50D0CA` FOREIGN KEY (`pId`) REFERENCES `t_channel` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_channel`
--


/*!40000 ALTER TABLE `t_channel` DISABLE KEYS */;
LOCK TABLES `t_channel` WRITE;
INSERT INTO `t_channel` VALUES (1,1,'',1,1,'网站首页',0,1,0,0,0,NULL),(3,1,'',1,1,'机构介绍',0,1,0,0,0,1),(4,1,'',1,1,'人事信息',0,2,0,0,0,1),(5,1,'',1,1,'领导名录',0,3,1,0,0,1);
UNLOCK TABLES;
/*!40000 ALTER TABLE `t_channel` ENABLE KEYS */;

--
-- Table structure for table `t_cms_link`
--

DROP TABLE IF EXISTS `t_cms_link`;
CREATE TABLE `t_cms_link` (
  `id` int(11) NOT NULL auto_increment,
  `new_win` int(11) default NULL,
  `pos` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(255) default NULL,
  `url` varchar(255) default NULL,
  `url_class` varchar(255) default NULL,
  `url_id` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_cms_link`
--


/*!40000 ALTER TABLE `t_cms_link` DISABLE KEYS */;
LOCK TABLES `t_cms_link` WRITE;
INSERT INTO `t_cms_link` VALUES (1,1,2,'百度','11111','www.baidu.com','1','1'),(2,0,1,'腾讯','腾讯连接','www.tengxun.com','2','2');
UNLOCK TABLES;
/*!40000 ALTER TABLE `t_cms_link` ENABLE KEYS */;

--
-- Table structure for table `t_group`
--

DROP TABLE IF EXISTS `t_group`;
CREATE TABLE `t_group` (
  `id` int(11) NOT NULL auto_increment,
  `descr` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_group`
--


/*!40000 ALTER TABLE `t_group` DISABLE KEYS */;
LOCK TABLES `t_group` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `t_group` ENABLE KEYS */;

--
-- Table structure for table `t_group_channel`
--

DROP TABLE IF EXISTS `t_group_channel`;
CREATE TABLE `t_group_channel` (
  `id` int(11) NOT NULL auto_increment,
  `c_id` int(11) default NULL,
  `g_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FKB7D322B8EA7D91B6` (`c_id`),
  KEY `FKB7D322B848103BAE` (`g_id`),
  CONSTRAINT `FKB7D322B848103BAE` FOREIGN KEY (`g_id`) REFERENCES `t_group` (`id`),
  CONSTRAINT `FKB7D322B8EA7D91B6` FOREIGN KEY (`c_id`) REFERENCES `t_channel` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_group_channel`
--


/*!40000 ALTER TABLE `t_group_channel` DISABLE KEYS */;
LOCK TABLES `t_group_channel` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `t_group_channel` ENABLE KEYS */;

--
-- Table structure for table `t_index_pic`
--

DROP TABLE IF EXISTS `t_index_pic`;
CREATE TABLE `t_index_pic` (
  `id` int(11) NOT NULL auto_increment,
  `create_date` datetime default NULL,
  `imgHeight` double NOT NULL,
  `imgWidth` double NOT NULL,
  `indexPicHeight` double NOT NULL,
  `indexPicWidth` double NOT NULL,
  `link_type` int(11) default NULL,
  `link_url` varchar(255) default NULL,
  `new_name` varchar(255) default NULL,
  `old_name` varchar(255) default NULL,
  `pos` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `sub_title` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_index_pic`
--


/*!40000 ALTER TABLE `t_index_pic` DISABLE KEYS */;
LOCK TABLES `t_index_pic` WRITE;
INSERT INTO `t_index_pic` VALUES (1,'2015-09-17 22:51:18',0,0,0,0,0,'','1442501468191.jpg','u=89686551,84464882&fm=24&gp=0.jpg',2,1,'dddd','ddddddddddddddddddd '),(2,'2015-09-17 22:51:55',0,0,0,0,1,'qq','1442501503600.jpg','u=261825178,2216988228&fm=24&gp=0.jpg',1,1,'a','ssssssssss ');
UNLOCK TABLES;
/*!40000 ALTER TABLE `t_index_pic` ENABLE KEYS */;

--
-- Table structure for table `t_keyword`
--

DROP TABLE IF EXISTS `t_keyword`;
CREATE TABLE `t_keyword` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `name_full_py` varchar(255) default NULL,
  `name_short_py` varchar(255) default NULL,
  `times` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_keyword`
--


/*!40000 ALTER TABLE `t_keyword` DISABLE KEYS */;
LOCK TABLES `t_keyword` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `t_keyword` ENABLE KEYS */;

--
-- Table structure for table `t_role`
--

DROP TABLE IF EXISTS `t_role`;
CREATE TABLE `t_role` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `role_type` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_role`
--


/*!40000 ALTER TABLE `t_role` DISABLE KEYS */;
LOCK TABLES `t_role` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `t_role` ENABLE KEYS */;

--
-- Table structure for table `t_topic`
--

DROP TABLE IF EXISTS `t_topic`;
CREATE TABLE `t_topic` (
  `id` int(11) NOT NULL auto_increment,
  `author` varchar(255) default NULL,
  `channel_pic_id` int(11) default NULL,
  `cname` varchar(255) default NULL,
  `content` varchar(255) default NULL,
  `create_date` datetime default NULL,
  `keyword` varchar(255) default NULL,
  `publish_date` datetime default NULL,
  `recommend` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `summary` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `cid` int(11) default NULL,
  `uid` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FKA10609A4EA509FFD` (`cid`),
  KEY `FKA10609A475F6975F` (`uid`),
  CONSTRAINT `FKA10609A475F6975F` FOREIGN KEY (`uid`) REFERENCES `t_user` (`id`),
  CONSTRAINT `FKA10609A4EA509FFD` FOREIGN KEY (`cid`) REFERENCES `t_channel` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_topic`
--


/*!40000 ALTER TABLE `t_topic` DISABLE KEYS */;
LOCK TABLES `t_topic` WRITE;
INSERT INTO `t_topic` VALUES (1,'李海',11,'机构介绍','合肥DFHD烦得很复合肥会儿','2015-09-15 22:01:58','你好 |你好�?|哈哈�?|火狐 |','2015-09-15 22:01:58',1,1,'都是独生对手覅U�?,'这个是最后一次测试文�?,3,3);
UNLOCK TABLES;
/*!40000 ALTER TABLE `t_topic` ENABLE KEYS */;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL auto_increment,
  `create_date` datetime default NULL,
  `email` varchar(255) default NULL,
  `nickname` varchar(255) default NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) default NULL,
  `status` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_user`
--


/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
LOCK TABLES `t_user` WRITE;
INSERT INTO `t_user` VALUES (3,'2015-09-14 22:17:47','123456789@qq.com','李海','553b3c7b029f6cc4228d4fbadc5e88ab','123456789',1,'lihai');
UNLOCK TABLES;
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;

--
-- Table structure for table `t_user_group`
--

DROP TABLE IF EXISTS `t_user_group`;
CREATE TABLE `t_user_group` (
  `id` int(11) NOT NULL auto_increment,
  `g_id` int(11) default NULL,
  `u_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK300645B648103BAE` (`g_id`),
  KEY `FK300645B6762B7434` (`u_id`),
  CONSTRAINT `FK300645B648103BAE` FOREIGN KEY (`g_id`) REFERENCES `t_group` (`id`),
  CONSTRAINT `FK300645B6762B7434` FOREIGN KEY (`u_id`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_user_group`
--


/*!40000 ALTER TABLE `t_user_group` DISABLE KEYS */;
LOCK TABLES `t_user_group` WRITE;
INSERT INTO `t_user_group` VALUES (1,1,3);
UNLOCK TABLES;
/*!40000 ALTER TABLE `t_user_group` ENABLE KEYS */;

--
-- Table structure for table `t_user_role`
--

DROP TABLE IF EXISTS `t_user_role`;
CREATE TABLE `t_user_role` (
  `id` int(11) NOT NULL auto_increment,
  `r_id` int(11) default NULL,
  `u_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK331DEE5F7628ABC2` (`r_id`),
  KEY `FK331DEE5F762B7434` (`u_id`),
  CONSTRAINT `FK331DEE5F7628ABC2` FOREIGN KEY (`r_id`) REFERENCES `t_role` (`id`),
  CONSTRAINT `FK331DEE5F762B7434` FOREIGN KEY (`u_id`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_user_role`
--


/*!40000 ALTER TABLE `t_user_role` DISABLE KEYS */;
LOCK TABLES `t_user_role` WRITE;
INSERT INTO `t_user_role` VALUES (2,1,3);
UNLOCK TABLES;
/*!40000 ALTER TABLE `t_user_role` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

